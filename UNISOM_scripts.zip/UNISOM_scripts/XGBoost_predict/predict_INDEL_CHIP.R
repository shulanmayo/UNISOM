####INDEL CHIP
library(caret)
library(xgboost)
library(mlr)

load("WES.INDEL.XGBoost.baseline.RData")

temp_df=unique(read.delim(file="sample_indel_feature_info.txt", sep="\t", header=T))

####nrow *24 for INDEL
test_data = as.matrix(temp_df[,18:41])
mode(test_data)="numeric"
rownames(test_data)=temp_df[,1]

# Transform the two data sets into xgb.Matrix
xgb.test = xgb.DMatrix(data=test_data)

# Predict outcomes with the test data
xgb.pred = predict(m0_xgb1,xgb.test,reshape=T)
xgb.pred = as.data.frame(xgb.pred)
colnames(xgb.pred) = c("ARTIFACTS", "CHIP", "GERMLINE")


# Use the predicted label with the highest probability
xgb.pred$prediction = apply(xgb.pred,1,function(x) colnames(xgb.pred)[which.max(x)])
xgb.pred$VAR=rownames(test_data)

var_df_full=merge(temp_df, xgb.pred, by.x="VAR_INDEX", by.y="VAR", all.x=F, all.y=F)
var_df_full$SAMPLE=gsub("[.]", "", var_df_full$SAMPLE)

###get rid of common variants
out_index=which((var_df_full$gnomAD.AF >=0.001) | (var_df_full$PG1000.AF >=0.001) | (var_df_full$TOPMED.AF >=0.001))
all_data_tmp1=var_df_full[-out_index,]


##AD2=0, if no reads support in one of callers
c_index=which((all_data_tmp1$AD2=="0") & (all_data_tmp1$CALLER_CALL=="1"))
all_data_tmp2=all_data_tmp1[-c_index,]

#####get rid of CHIPs in SD,MAP, etc low confident regions
noise_index=which((all_data_tmp2$FILTER=="SD,MAP") | (all_data_tmp2$FILTER=="RMSK,LCR") | (all_data_tmp2$FILTER=="SD,RMSK"))
all_data_tmp3=all_data_tmp2[-noise_index,]

####get predicted CHIP
chip_index=which(all_data_tmp3$prediction=="CHIP")

var_df_chip=all_data_tmp3[chip_index,]
var_df_rest=all_data_tmp3[-chip_index,]

####get recovered CHIPs

####if called by at least two callers and known CHIPs
recover_index=which((var_df_rest$CALLER_CALL >=2) & (!is.na(var_df_rest$KNOWN_CHIP.CHIP_VAF)))
var_df_rest_chip=var_df_rest[recover_index,]

####all predicted CHIP candidates
all_chip_df=rbind(var_df_chip, var_df_rest_chip)

####keep CHIP with VAF >=2%
keep_index=which(all_chip_df$AF >=0.02)
all_chip_final=all_chip_df[keep_index,]

write.table(all_chip_final, file="sample_predicted_INDEL_CHIP.txt", sep="\t", row.names=F, col.names=F, quote=F)
