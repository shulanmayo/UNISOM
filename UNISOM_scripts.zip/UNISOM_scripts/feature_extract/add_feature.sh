#####CAVA 
CAVA_PATH=CAVA-1.2.3/cava
CAVA_CONFIG=config.123.txt

#####genomic resources

####genomic-context
DBSNP_VCF=${CHIP_PUB_hg19_data}"/"dbsnp_138.hg19.sorted.vcf
LCR_BED=${CHIP_PUB_hg19_data}"/"LCR_hg37d5_all.bed
CPG_BED=${CHIP_PUB_hg19_data}"/"hg19.CpG.fixed.sorted.bed
SD_L_BED=${CHIP_PUB_hg19_data}"/"hg19.segdup.fixed.sorted.bed
Mappability_BED=${CHIP_PUB_hg19_data}"/"hg19.wgEncodeCrgMapabilityAlign100mer.DUP2.CHIP.sorted.bed
RMSK_BED=${CHIP_PUB_hg19_data}"/"hg19.rmsk.fixed.sorted.bed

#####germline/somatic databases
PG1000_hg19_VCF=${CHIP_MAF_hg19_data}"/"PG_1000.CHIP_GENE.hg19.AF_only.sorted.vcf
gnomAD_hg19_VCF=${CHIP_MAF_hg19_data}"/"gnomAD.CHIP_GENE.hg19.AF_only.sorted.vcf
TOPMED_hg19_VCF=${CHIP_MAF_hg19_data}"/"TOPMED.CHIP_GENE.hg19.AF_only.sorted.vcf
COSMIC_hg19_VCF=${CHIP_MAF_hg19_data}"/"COSMIC.CHIP_GENE.hg19.CNT_only.sorted.vcf
CHIP_FILE=${CHIP_MAF_hg19_data}"/"ALL_CHIP_POS_hg19.merged.vcf

######add quality-based feature
java -jar GenomeAnalysisTK.jar \
-T VariantAnnotator \
-R reference.fa \
-I sample.bam \
-V sample.merged.raw.vcf \
--dbsnp $DBSNP_VCF \
-A Coverage \
-A FisherStrand \
-A GCContent \
-A HomopolymerRun \
-A LowMQ \
-A ClippingRankSumTest \
-A MappingQualityRankSumTest \
-A MappingQualityZero \
-A NBaseCount \
-A QualByDepth \
-A AlleleBalance \
-A BaseCounts \
-A RMSMappingQuality \
-A ReadPosRankSumTest \
-A SpanningDeletions \
-A StrandOddsRatio \
-A TandemRepeatAnnotator \
-o sample.merged.raw.ann.vcf

####add genomic-context related
java -jar GenomeAnalysisTK.jar \
-T VariantFiltration \
-R reference.fa \
-V sample.merged.raw.ann.vcf \
--mask $LCR_BED --maskName LCR \
-o sample.merged.raw.ann.LCR.vcf

rm sample.merged.raw.ann.vcf* 

####add genomic-context related
java -jar GenomeAnalysisTK.jar \
-T VariantFiltration \
-R reference.fa \
-V sample.merged.raw.ann.LCR.vcf \
--mask $CPG_BED --maskName CPG \
-o sample.merged.raw.ann.LCR.CPG.vcf

####add genomic-context related
java -jar GenomeAnalysisTK.jar \
-T VariantFiltration \
-R reference.fa \
-V sample.merged.raw.ann.LCR.CPG.vcf \
--mask $RMSK_BED --maskName RMSK \
-o sample.merged.raw.ann.LCR.CPG.RMSK.vcf

####add genomic-context related
java -jar GenomeAnalysisTK.jar \
-T VariantFiltration \
-R reference.fa \
-V sample.merged.raw.ann.LCR.CPG.RMSK.vcf \
--mask $SD_L_BED --maskName SD \
-o sample.merged.raw.ann.LCR.CPG.RMSK.SD.vcf

####add genomic-context related
java -jar GenomeAnalysisTK.jar \
-T VariantFiltration \
-R reference.fa \
-V sample.merged.raw.ann.LCR.CPG.RMSK.SD.vcf \
--mask $Mappability_BED --maskName MAP \
-o sample.merged.raw.ann.LCR.CPG.RMSK.SD.MAP.vcf

####add MAF-related
java -jar GenomeAnalysisTK.jar \
-T VariantAnnotator \
-R reference.fa \
-I sample.bam \
-V sample.merged.raw.ann.LCR.CPG.RMSK.SD.MAP.vcf \
--resource:gnomAD $gnomAD_hg19_VCF \
--resource:PG1000 $PG1000_hg19_VCF \
--resource:TOPMED $TOPMED_hg19_VCF \
--resource:COSMIC $COSMIC_hg19_VCF \
--resource:KNOWN_CHIP $CHIP_FILE \
-E PG1000.AF -E gnomAD.AF -E TOPMED.AF -E COSMIC.CNT -E KNOWN_CHIP.CHIP_VAF \
-o sample.merged.raw.ann.flag.vcf

$CAVA_PATH -c $CAVA_CONFIG \
-i sample.merged.raw.ann.flag.vcf \
-o sample.merged.raw.ann.flag.cava

gatk VariantsToTable \
-R reference.fa \
-O sample.merged.raw.ann.cava.table.txt \
-V sample.merged.raw.ann.flag.cava.vcf \
--show-filtered \
-F CHROM -F POS -F ID -F REF -F ALT -F QUAL -F FILTER  \
-F BaseQRankSum -F FS -F GC -F HRun -F LowMQ -F MQ -F MQ0 -F MQRankSum -F OND -F PercentNBase \
-F QD -F ReadPosRankSum -F SQR -F STR -F DP \
-F SOURCE -F TYPE -F TRANSCRIPT -F GENE -F GENEID -F SO -F IMPACT -F CSN -F CLASS \
-F gnomAD.AF -F PG1000.AF -F TOPMED.AF -F COSMIC.CNT -F KNOWN_CHIP.CHIP_VAF \
-F GT -F AF -F AD1 -F AD2

#####only keep variants with functional impact
egrep "CHROM|stop|gain|frame|splice|missense" sample.merged.raw.ann.cava.table.txt >sample.merged.raw.ann.cava.coding

rm sample.merged.raw.ann.LCR.*
rm sample.merged.raw.ann.flag.vcf*
