#prepare output for classifer

#####fix FILTER, YES/NO----1/0

fix_filter_fun=function(df, term="MAP", col=43, label="MAP") {
sd_index=grep(term, df$FILTER)
df[sd_index,col]=1
df[-sd_index,col]=0
colnames(df)[col]=label
return(df)
}

#####breakdown source, caller, YES/NO---------1/0

fix_source_fun=function(df, term="mutect2", col=40, label="MUTECT_CALL") {
index_1=grep(term, df$SOURCE)
index_2=grep("Intersection", df$SOURCE)
df[c(index_1, index_2),col]=1
df[-c(index_1, index_2),col]=0
colnames(df)[col]=label
return(df) 
}

#####sample.merged.raw.ann.cava.coding

raw_file="sample.merged.raw.ann.cava.coding"
temp_in=read.delim(file=raw_file, sep="\t", header=T)

####
ann_df=temp_in[,c(1:5,7,24:31,36)]
all_df=temp_in[,c(1:5,7,9:11,13:14,17,21,22:24,32:36,38:40)]

#####fix source
all_df=fix_source_fun(df=all_df, term="mutect2", col=25, label="MUTECT_CALL")
all_df=fix_source_fun(df=all_df, term="vardict", col=26, label="VARDICT_CALL")
all_df=fix_source_fun(df=all_df, term="VarTracker", col=27, label="VarTracker_CALL")

######fix the filter
all_df=fix_filter_fun(df=all_df, term="MAP", col=28, label="MAP")
all_df=fix_filter_fun(df=all_df, term="RMSK", col=29, label="RMSK")
all_df=fix_filter_fun(df=all_df, term="LCR", col=30, label="LCR")

all_df=fix_filter_fun(df=all_df, term="CPG", col=31, label="CPG")
all_df=fix_filter_fun(df=all_df, term="SD", col=32, label="SD")

#######one caller----1, two caller---2, 3 callers----3
all_df_final=cbind(rep(s_name, dim(all_df)[1]), all_df, rep(0,dim(all_df)[1]))
colnames(all_df_final)[c(1,34)]=c("SAMPLE", "CALLER_CALL")

#######
one_index=which((all_df_final$SOURCE == "VarTracker") | (all_df_final$SOURCE == "vardict") |(all_df_final$SOURCE == "mutect2"))
all_df_final[one_index, 34]=1

two_index=which((all_df_final$SOURCE == "mutect2-vardict") | (all_df_final$SOURCE == "mutect2-VarTracker") |(all_df_final$SOURCE == "vardict-VarTracker"))
all_df_final[two_index, 34]=2

three_index=which(all_df_final$SOURCE == "Intersection")
all_df_final[three_index, 34]=3


#########GC, HRun, MQ, PercentNBase, ####YES/NO---------1/0
##STR ####YES/NO---------1/0

str_index=which(as.character(all_df_final$STR)=="true")

if(length(str_index) >=1) {
all_df_final[str_index,35]=1
all_df_final[-str_index,35]=0 }

colnames(all_df_final)[35]="STR_CALL"

#########
g_index=which(is.na(all_df_final$gnomAD.AF))
all_df_final$gnomAD.AF[g_index]=0

k_index=which(is.na(all_df_final$PG1000.AF))
all_df_final$PG1000.AF[k_index]=0

e_index=which(is.na(all_df_final$TOPMED.AF))
all_df_final$TOPMED.AF[e_index]=0

c_index=which(is.na(all_df_final$COSMIC.CNT))
all_df_final$COSMIC.CNT[c_index]=0

######RS ID
#all_df_final$ID=as.character(all_df_final$ID)
r_index=which(all_df_final$ID ==".")

all_df_final$RS_ID[r_index]=1
all_df_final$RS_ID[-r_index]=0


#######mutation pattern ####C/T ot G/A ####YES/NO---------1/0

all_df_final_tmp=cbind(all_df_final, paste(all_df_final[,5], all_df_final[,6], sep="_"), rep(0, dim(all_df_final)[1]))

colnames(all_df_final_tmp)[37:38]=c("PAT", "MUT_SIG")

####C-T or G-A
m_index=which((all_df_final_tmp$PAT =="C_T") | (all_df_final_tmp$PAT =="G_A"))

all_df_final_tmp$MUT_SIG[m_index]=1
all_df_final_tmp$MUT_SIG[-m_index]=0

######indel and snv df
all_snv_df=all_df_final_tmp[all_df_final_tmp$TYPE=="SNP",]
all_indel_df=all_df_final_tmp[all_df_final_tmp$TYPE=="INDEL",]

#########

all_snv_df_ann=unique(merge(ann_df, all_snv_df[,-22], by.x=colnames(ann_df)[1:6], by.y=colnames(all_snv_df[,-22])[2:7], all.x=F, all.y=T))
all_indel_df_ann=unique(merge(ann_df, all_indel_df[,-22], by.x=colnames(ann_df)[1:6], by.y=colnames(all_indel_df[,-22])[2:7], all.x=F, all.y=T))

write.table(all_snv_df_ann, file="sample_snv_feature_info.txt", sep="\t", row.names=F, quote=F)
write.table(all_indel_df_ann, file="sample_indel_feature_info.txt", sep="\t", row.names=F, quote=F)

#######a total of 26 features for SNV - 1 label for prior
all_snv_df_sv=data.frame(cbind(paste("ID", 1:dim(all_snv_df_ann)[1], sep="_"), all_snv_df_ann[,c(1:16,17:22,24,27:44,46)]))
colnames(all_snv_df_sv)[1]="VAR_INDEX"

########indel, 24 feature
all_indel_df_sv=data.frame(cbind(paste("ID", 1:dim(all_indel_df_ann)[1], sep="_"), all_indel_df_ann[,c(1:16,18:20,22,24,27:44,46)]))
colnames(all_indel_df_sv)[1]="VAR_INDEX"

fill_index=which(is.na(all_indel_df_sv$HRun))
all_indel_df_sv[fill_index,19]=0

####input for classifier
write.table(all_snv_df_sv, file="sample_snv_feature.txt", sep="\t", row.names=T, quote=F)
write.table(all_indel_df_sv, file="sample_indel_feature.txt", sep="\t", row.names=T, quote=F)
