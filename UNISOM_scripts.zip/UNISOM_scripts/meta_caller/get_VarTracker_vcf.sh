
###call with VarTracker
###need a loop to go through all intervals

mkdir -p sample
cd sample

####loop start here

NL=$(cat ON_TARGET.bed |awk 'END {print NR}')

for ((k=1;k<=$NL;k++)) 
do
REGION=$(cat ON_TARGET.bed |awk -v n=$k 'BEGIN {FS=OFS="\t"} {if (NR==n) print}')
bcftools mpileup -C 0  -d 1000 -r $REGION --output-type v -f reference.fa --output sample.pileup.$k.vcf sample.bam
done

#### loop ends here

cat sample.pileup.*.vcf | grep -v "#" >sample.PU.single.all.temp1

rm sample.pileup.*.vcf

sed -i 's/,<\*>//g' sampel.PU.single.all.temp1
grep -v "<*>" sample.PU.single.all.temp1 >sample.PU.single.all.temp

rm sample.PU.single.all.temp1

cat VarTracker_VCF_HEADER sample.PU.single.all.temp >sample.pileup.single.temp.vcf

rm sample.PU.single.all.temp

java -jar picard.jar SortVcf \
I=sample.pileup.single.temp.vcf \
O=sample.pileup.single.temp.sorted.vcf \
VALIDATION_STRINGENCY=LENIENT

rm sample.pileup.single.temp.vcf*

java -jar GenomeAnalysisTK.jar \
-T UnifiedGenotyper \
-R reference.fa \
-L sample.pileup.single.temp.sorted.vcf \
-gt_mode GENOTYPE_GIVEN_ALLELES \
--alleles sample.pileup.single.temp.sorted.vcf \
-A Coverage -A DepthPerAlleleBySample -A QualByDepth \
-A NBaseCount -A HomopolymerRun -A LowMQ -A SpanningDeletions -A TandemRepeatAnnotator \
-A MappingQualityRankSumTest -A ReadPosRankSumTest \
-A MappingQualityZero -A RMSMappingQuality -A FisherStrand \
-glm BOTH -G none -out_mode EMIT_ALL_SITES -U \
-o sample.pileup.single.backfill.vcf \
-I sample.bam

rm sample.pileup.single.temp.sorted.vcf*

java -jar GenomeAnalysisTK.jar \
-T VariantsToAllelicPrimitives \
-R reference.fa \
-V sample.pileup.single.backfill.vcf \
-o sample.pileup.single.primitives.vcf

rm sample.pileup.single.backfill.vcf*

java -jar GenomeAnalysisTK.jar \
-T LeftAlignAndTrimVariants \
-R reference.fa \
-V sample.pileup.single.primitives.vcf \
-o sample.pileup.single.raw.formated.vcf

rm sample.pileup.single.primitives.vcf*

cat sample.pileup.single.raw.formated.vcf | \
grep -v "^#" | \
awk 'BEGIN {FS=OFS="\t"} {if ($5 !~ /\,/) print $0,$5,$10}' > sample.pileup.single.best_allele.vcf

###### extract variants with two or more alternate alleles
###### Only keep a single alt allele one with the most supporting reads
###### choose a random one if with the same number of supporting reads 

###### extract variants with >=2 alternate alleles
###### column 10 must have GT info. i.e., can not be "./."
###### number of "," has to be the same between column 6 (GT info) and # supporting reads in column 10
###### total: 22605

cat sample.pileup.single.raw.formated.vcf | \
grep -v "^#" | \
awk 'BEGIN {FS=OFS="\t"} {if (($5 ~ /\,/) && ($10 ~ /[0-9]/)) print $0,$5,$10}' | \
awk 'BEGIN {FS=OFS="\t"} {gsub(/[A-Z]/,"",$11); gsub(/^[0-9\/]+\:[0-9]+\,/,"",$12); print}' | \
awk 'BEGIN {FS=OFS="\t"} {gsub(/\:[0-9\,\:]+$/,"",$12); print}' | \
awk 'BEGIN {FS=OFS="\t"} {gsub(/[0-9]+/,"",$12); print}' | \
awk 'BEGIN {FS=OFS="\t"} {if ((length($11) == length($12)) && ($11 ~ /\,/) && ($12 ~ /\,/)) print}' | \
cut -d$'\t' -f 1-10 > \
sample.pileup.single.sub2.vcf

rm sample.pileup.single.raw.formated.vcf*

###### parse a single alt allele with the most supporting reads 

cat sample.pileup.single.sub2.vcf | \
awk 'BEGIN {FS=OFS="\t"} {print NR,$0,$5,$5,$10}' | \
awk 'BEGIN {FS=OFS="\t"} {gsub(/\:/,"\t",$14); print}' | \
cut -d$'\t' -f 1-13,15 | \
awk 'BEGIN {FS=OFS="\t"} {gsub(/[A-Z]/,"",$12); gsub(/^[0-9]+\,/,"",$14); print}' | \
awk 'BEGIN {FS=OFS="\t"} {gsub(/\,/,"\t",$13); gsub(/\,/,"\t",$14); print}' | \
awk 'BEGIN {FS="\t"; OFS="\t"} {for(i=13; i<=13+length($12); i++) print $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$i,$(i+length($12)+1)}' | \
sort -k1,1n -k14,14n | \
awk 'BEGIN {FS=OFS="\t"} {a[$1] = $0} END { for (x in a) { print a[x] } }' | \
sort -k1,1n | \
cut -d$'\t' -f 1-11,13-14 > \
sample.pileup.single.sub2.parsed.vcf

###### re-generate column 10 by inserting #supporting reads for a single parsed alt allele
###### also replace column 5 with a single parsed alt allele 
###### in the output, col11 is the original column 5, col12 is the original column 10

cat sample.pileup.single.sub2.parsed.vcf | \
cut -d$'\t' -f 11,13 | \
awk 'BEGIN {FS=OFS="\t"} {print $1,$1,$2}' | \
awk 'BEGIN {FS=OFS="\t"} {gsub(/\,[0-9\:\,]+$/,"",$1); gsub(/^[0-9\/]+\:[0-9\,]+/,"",$2); print}' | \
awk 'BEGIN {FS=OFS="\t"} {print $1","$3$2}' | \
paste sample.pileup.single.sub2.parsed.vcf - | \
awk 'BEGIN {FS=OFS="\t"} {print $2,$3,$4,$5,$12,$7,$8,$9,$10,$14,$6,$11}' >> \
sample.pileup.single.best_allele.vcf

rm sample.pileup.single.sub2.parsed.vcf*

######reformat
cut -f 1-10 sample.pileup.single.best_allele.vcf >sample.pileup.single.best_allele.vcf.temp
cat VarTracker_VCF_HEADER sample.pileup.single.best_allele.vcf.temp >sample.pileup.single.best_allele.temp.vcf

bcftools query -f '%CHROM\t%POS\t%ID\t%REF\t%ALT\t%QUAL\t%FILTER[\t%GT\t%DP\t%AD\t%AD]\n' \
sample.pileup.single.best_allele.temp.vcf | awk 'BEGIN {FS=OFS="\t"} {gsub(/,/,"\t",$11); print}' | \
awk 'BEGIN {FS=OFS="\t"} { print $1,$2,$3,$4,$5,"50","PASS",".","GT:AD:AF","0/1:"$10":"$12/($9+0.1)}' \
>sample.pileup.single.raw.fixed.temp

grep -v "N" sample.pileup.single.raw.fixed.temp >sample.pileup.single.raw.fixed.temp2
cat VarTracker_VCF_HEADER sample.pileup.single.raw.fixed.temp2 >sample.VarTracker.raw.vcf

rm sample.pileup.single.best_allele.vcf*
rm sample.pileup.single.best_allele.vcf.temp
rm sample.pileup.single.best_allele.temp.vcf*
rm sample.pileup.single.raw.fixed.temp
rm sample.pileup.single.raw.fixed.temp2
