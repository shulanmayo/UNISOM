
####
java -jar GenomeAnalysisTK.jar \
-T Mutect2 \
-R reference.fa \
-L ON_TARGET.interval_list \
-I:tumor sample.bam \
-O sample.mutect2.vcf

bcftools query -f '%CHROM\t%POS\t%ID\t%REF\t%ALT\t%QUAL\t%FILTER[\t%GT\t%AD\t%AF]\n' \
sample.mutect2.vcf \
| awk 'BEGIN {FS=OFS="\t"} { print $1,$2,".",$4,$5,"50","PASS",".","GT:AD:AF",$8":"$9":"$10}'\
| cat $VCF_HEADER  - >sample.mutect2.raw.vcf
