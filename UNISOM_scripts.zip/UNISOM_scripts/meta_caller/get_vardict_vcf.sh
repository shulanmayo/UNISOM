
######downloaded vardict version
VARDICT_DIR=vardict/20180130
VARDICT=${VARDICT_DIR}"/"vardict

#####call with vardict
vardict -G reference.fa \
-f 0.01 \
-N sample \
-b sample.bam \
-c 1 -S 2 -E 3 -g 4 \
ON_TARGET.bed | ${VARDICT_DIR}/teststrandbias.R | ${VARDICT_DIR}/var2vcf_valid.pl -N sample -f 0.01 \
>sample.vardict.vcf

#####sort vcf
igvtools sort sample.vardict.vcf sample.vardict.sorted.vcf
igvtools index sample.vardict.sorted.vcf

rm sample.vardict.vcf*

###fix header
awk 'BEGIN {FS=OFS="\t"} {if ($0 ~ /^\#CHROM/) print "#CHROM","POS","ID","REF","ALT","QUAL","FILTER","INFO","FORMAT","SAMPLE"; else print $0}' \
sample.vardict.sorted.vcf >sample.vardict.sorted.temp.vcf

rm sample.vardict.sorted.vcf*

###fix variantcontext
####fix $8 for vardict
awk 'BEGIN {FS=OFS="\t"} {if ($0 ~ /^\#/) print $0; else if (($0 !~/^#/) && ($4 !=$5)) print $1,$2,".",$4,$5,$6,"PASS",".",$9,$10}' \
sample.vardict.sorted.temp.vcf > sample.vardict.fixed.vcf

rm sample.vardict.sorted.temp.vcf*

java -jar GenomeAnalysisTK.jar \
-T VariantsToAllelicPrimitives \
-R reference.fa \
-V sample.vardict.fixed.vcf \
-o sample.vardict.primitives.vcf

rm sample.vardict.fixed.vcf*

java -jar GenomeAnalysisTK.jar \
-T LeftAlignAndTrimVariants \
-R reference.fa \
-V sample.vardict.primitives.vcf \
-o sample.vardict.primitives.aligned.vcf

rm sample.vardict.primitives.vcf*

bcftools query -f '%CHROM\t%POS\t%ID\t%REF\t%ALT\t%QUAL\t%FILTER[\t%GT\t%AD\t%AF]\n' \
sample.vardict.primitives.aligned.vcf | \
awk 'BEGIN {FS=OFS="\t"} { print $1,$2,".",$4,$5,"50","PASS",".","GT:AD:AF",$8":"$9":"$10}' | \
cat $VCF_HEADER  - >sample.vardict.raw.vcf

rm sample.vardict.primitives.aligned.vcf*
