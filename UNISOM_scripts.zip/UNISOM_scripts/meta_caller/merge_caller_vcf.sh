
#####merge raw vcf files from 3 callers

####sort vcf files before merging
java -jar picard.jar SortVcf \
I=sample.mutect2.raw.vcf \
O=sample.mutect2.raw.sorted.vcf \
SEQUENCE_DICTIONARY=reference.dict \
VALIDATION_STRINGENCY=LENIENT

java -jar picard.jar SortVcf \
I=sample.vardict.raw.vcf \
O=sample.vardict.raw.sorted.vcf \
SEQUENCE_DICTIONARY=reference.dict \
VALIDATION_STRINGENCY=LENIENT

java -jar picard.jar SortVcf \
I=sample.VarTracker.raw.vcf \
O=sample.VarTracker.raw.sorted.vcf \
SEQUENCE_DICTIONARY=reference.dict \
VALIDATION_STRINGENCY=LENIENT

java -jar GenomeAnalysisTK.jar \
-T CombineVariants \
-R reference.fa \
--variant:mutect2 sample.mutect2.raw.sorted.vcf \
--variant:vardict sample.vardict.raw.sorted.vcf \
--variant:VarTracker sample.VarTracker.raw.sorted.vcf \
-genotypeMergeOptions PRIORITIZE \
-priority mutect2,vardict,VarTracker \
-setKey SOURCE \
-o sample.merged.raw.tmp.vcf

#####reformat merged vcf file
grep "#" sample.merged.raw.tmp.vcf >sample.HEADER.tmp
awk 'BEGIN {FS=OFS="\t"} {if ($0 ~ /^\##/) print $0; else print $1,$2,$3,$4,$5,$6,$7,$8}' sample.HEADER.tmp >sample.HEADER

bcftools query -f '%CHROM\t%POS\t%ID\t%REF\t%ALT\t%QUAL\t%SOURCE[\t%GT\t%AF\t%AD]\n' \
sample.merged.raw.tmp.vcf | \
awk 'BEGIN {FS=OFS="\t"} {gsub(/,/,"\t",$10); print}' | \
awk 'BEGIN {FS=OFS="\t"} {if (NF==11) print; else if (NF >11) print $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11}' | \
awk 'BEGIN {FS=OFS="\t"} { print $1,$2,".",$4,$5,"50","PASS","SOURCE="$7";GT="$8";AF="$9";AD1="$10";AD2="$11}' | \
cat sample.HEADER - >sample.merged.raw.vcf

sed  -i '4i ##INFO=<ID=AD1, Number=1,Type=String, Description="REF_Depth">' sample.merged.raw.vcf
sed  -i '4i ##INFO=<ID=AD2, Number=1,Type=String, Description="ALT_Depth">' sample.merged.raw.vcf
sed  -i '4i ##INFO=<ID=GT, Number=1,Type=String, Description="GT">' sample.merged.raw.vcf
sed  -i '4i ##INFO=<ID=AF, Number=1,Type=String, Description="AF">' sample.merged.raw.vcf

rm sample.*.sorted.vcf*
rm sample.merged.raw.tmp.vcf*
rm sample.HEADER*
